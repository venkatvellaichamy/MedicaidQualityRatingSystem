﻿var reports = [
    
    { "id": "2", "name": "Adult Body Mass Index (BMI) Assessment", "type": "Adult", "BenchMarkValue": "15", "AverageValue": "19", "Indicator": "0" },
    { "id": "3", "name": "Breast Cancer Screening  ", "type": "Adult", "BenchMarkValue": "10", "AverageValue": "11.25", "Indicator": "0" },
    { "id": "4", "name": "Follow-Up After Hospitalization for Mental illness  ", "type": "Adult", "BenchMarkValue": "7", "AverageValue": "11", "Indicator": "0" },
    { "id": "5", "name": "CAHPS Health Plan Survey 5.0H – Adult Questionnaire", "type": "Adult", "BenchMarkValue": "20", "AverageValue": "17", "Indicator": "0" },
    { "id": "6", "name": "Comprehensive Diabetes Care: LDL-C Screening ", "type": "Adult", "BenchMarkValue": "10", "AverageValue": "16", "Indicator": "0" },
    { "id": "8", "name": "Plan All-Cause Readmission Rate ", "type": "Adult", "BenchMarkValue": "11", "AverageValue": "15.5", "Indicator": "0" },
    { "id": "9", "name": "Annual HIV/AIDS Medical Visit", "type": "Adult", "BenchMarkValue": "10", "AverageValue": "17.5", "Indicator": "0" },
    { "id": "10", "name": "Initiation and Engagement of Alcohol and Other Drug Dependence Treatment", "type": "Adult", "BenchMarkValue": "15000", "AverageValue": "19500", "Indicator": "0" },
    { "id": "11", "name": "Flu Shots for Adults Ages 50 to 64", "type": "Adult", "BenchMarkValue": "10", "AverageValue": "14.25", "Indicator": "0" },
    { "id": "17", "name": "Chronic Obstructive Pulmonary Disease (COPD) Admission Rate ", "type": "Adult", "BenchMarkValue": "28", "AverageValue": "24.5", "Indicator": "1" },

    { "id": "1", "name": "Weight Assessment and Counseling for Nutrition and Physical Activity for Children/ Adolescents: BMI Assessment for Children/ Adolescents", "type": "CHIPRA", "BenchMarkValue": "16", "AverageValue": "21.75", "Indicator": "0" },
    { "id": "2", "name": "Human Papillomavirus (HPV) Vaccine for Female Adolescents", "type": "CHIPRA", "BenchMarkValue": "17", "AverageValue": "18", "Indicator": "0" },
    { "id": "3", "name": "Well-Child Visits in the First 15 Months of Life", "type": "CHIPRA", "BenchMarkValue": "15", "AverageValue": "17.75", "Indicator": "0" },
    { "id": "4", "name": "Child and Adolescent Access to Primary Care Practitioners", "type": "CHIPRA", "BenchMarkValue": "21", "AverageValue": "17.75", "Indicator": "0" },
    { "id": "5", "name": "Childhood Immunization Status  ", "type": "CHIPRA", "BenchMarkValue": "20", "AverageValue": "26", "Indicator": "0" },
    { "id": "6", "name": "Immunization Status for Adolescents ", "type": "CHIPRA", "BenchMarkValue": "32", "AverageValue": "29.5", "Indicator": "0" },
    { "id": "7", "name": "Frequency of Ongoing Prenatal Care  ", "type": "CHIPRA", "BenchMarkValue": "20", "AverageValue": "25.75", "Indicator": "0" },
    { "id": "8", "name": "Timeliness of Prenatal Care", "type": "CHIPRA", "BenchMarkValue": "15", "AverageValue": "20.5", "Indicator": "0" },
    { "id": "9", "name": "Live Births Weighing Less Than 2,500 Grams ", "type": "CHIPRA", "BenchMarkValue": "33", "AverageValue": "28", "Indicator": "1" },
    { "id": "10", "name": "Cesarean Rate for Nulliparous Singleton Vertex", "type": "CHIPRA", "BenchMarkValue": "15", "AverageValue": "18", "Indicator": "0" },

    { "id": "1", "name": "Average Time to Process", "type": "Others", "BenchMarkValue": "13", "AverageValue": "15", "Indicator": "1" },
    { "id": "2", "name": "Average Provider Application Time Processing", "type": "Others", "BenchMarkValue": "30", "AverageValue": "35", "Indicator": "1" },
    { "id": "3", "name": "Average Days to Pay Claims", "type": "Others", "BenchMarkValue": "30", "AverageValue": "41", "Indicator": "1" },
    { "id": "4", "name": "Average Days to Pay 90 percent of Claims", "type": "Others", "BenchMarkValue": "25", "AverageValue": "31", "Indicator": "1" },
    { "id": "5", "name": "Administrative cost per claim", "type": "Others", "BenchMarkValue": "12", "AverageValue": "14.5", "Indicator": "1" },
    { "id": "6", "name": "Provider Enrollment and Claims Payment Satisfaction Rate", "type": "Others", "BenchMarkValue": "85", "AverageValue": "78", "Indicator": "0" },
    { "id": "7", "name": "Denial Rate", "type": "Others", "BenchMarkValue": "3.5", "AverageValue": "4.5", "Indicator": "1" }
];

var filters = [{ "name": "Adult" },
    { "name": "CHIPRA" },
    { "name": "Others"}];