﻿var Site = angular.module("Site", ["ui.router"])
.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/login")
    $stateProvider
        .state('login', {
            url: "/login",
            templateUrl: "/partials/login.htm"
        })
        .state('dashboard', {
            url: "/dashboard",
            templateUrl: "/partials/dashboard.htm",
            controller: dashboardController
        })
        .state('settings', {
            url: "/settings",
            templateUrl: "/partials/settings.htm"
        })
});
Site.controller(controllers)


    /*Site.config(function ($routeProvider) {
    $routeProvider
    .when('/login', { templateUrl: '/partials/login.htm' })
    .when('/about', { templateUrl: '/partials/about.htm' })
    .when('/dashboard', { templateUrl: '/partials/dashboard.htm' })
    .when('/settings/dashboard', { templateUrl: '/partials/settings/dashboardsettings.htm' })
    .when('/settings/user', { templateUrl: '/partials/settings/usersettings.htm' })
    .otherwise({ redirectTo: '/' });
    });*/

    //.config(function ($stateProvider, $urlRouterProvider) {
    //    $stateProvider
    //    .state('login', { url: '/login', templateUrl: '/partials/login.htm' })
    //    .state("otherwise", { url: "*path", templateUrl: "/login" })
    //});