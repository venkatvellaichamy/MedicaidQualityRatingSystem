﻿var controllers = {};

controllers.simpleController = function ($scope) {
    $scope.reports =
        [
            { id: '1', description: 'report 1' },
            { id: '2', description: 'report 2' }
        ];
}

controllers.navigateController = function ($scope) {
    $scope.settingslinks =
        [
            { link: 'user settings', url: '#/settings/user' },
            { link: 'dashboard settings', url: '#/settings/dashboard' }
        ];
}

function dashboardController($scope) {
    //$scope.reports = reports;
    $scope.filters = filters
}